﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        public  Form1()
        {
            InitializeComponent();
            this.TransparencyKey = (BackColor);
            this.WindowState = FormWindowState.Maximized;
        
      

        }
        public void uxDraw_Click(object sender,EventArgs e)
        {
            using (WindowGraphics wg = new WindowGraphics(this))
            {

                Graphics g = wg.Graphics;
                Pen p = new Pen(Brushes.DeepSkyBlue);
                p.Width = 9.0F;
                g.DrawRectangle(p, new Rectangle(30, 40, 150, 200));
            }
            System.Drawing.SolidBrush myBrush = new System.Drawing.SolidBrush(System.Drawing.Color.Red);
            System.Drawing.Graphics formGraphics;
            formGraphics = this.CreateGraphics();
            formGraphics.FillRectangle(myBrush, new Rectangle(0, 0, 200, 300));
            myBrush.Dispose();
            formGraphics.Dispose();

        }
    }
}
